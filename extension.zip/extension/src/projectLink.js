(function() {
  window.open('http://www.baidu.com')
})()